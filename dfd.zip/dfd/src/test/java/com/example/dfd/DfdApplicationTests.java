package com.example.dfd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DfdApplicationTests {

	@Test
	void contextLoads() {
	}

}
